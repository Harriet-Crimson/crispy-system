/*
created on 3rd February 2026
description: AudioReceiver java file decrypts and plays VoIP packets
version: 1.6
date: 08/03/2026
author(s): Harriet Smith
*/

import CMPC3M06.AudioPlayer;

import java.nio.ByteBuffer;
import java.util.Arrays;

import javax.sound.sampled.LineUnavailableException;
import java.io.IOException;

import java.net.*;

public class AudioReceiver extends AudioStandards implements Runnable{
    static DatagramSocket receiving_socket;
    //private AudioPlayer player = new AudioPlayer();
    static int[] clientPublicKey;
    private int key;
    private int key2;
    private byte[] tempAudioBuffer = new byte[audioBufferSize];

    public AudioReceiver() throws LineUnavailableException {
    }

    public void start(){ //sub-routine for starting the thread
        Thread thread = new Thread(this);
        thread.start();
    }
    public void run(){
        try{
            receiving_socket = new DatagramSocket(PORT);
        } catch (SocketException e){
            System.out.println("ERROR: AudioReceiver: Could not open UDP socket to receive from.");
            e.printStackTrace();
            System.exit(0);
        }
        boolean running = true;

        System.out.println(" Establishing connection...");
        while (running){
            try{
                //establish connection first
                byte[] buffer = new byte[5];
                DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
                receiving_socket.receive(packet);//receive public key
                clientPublicKey = new int[]{buffer[1], buffer[2]};
                if (buffer[0] == (byte)-1) {
                    RSAdecryption(buffer[3],buffer[4]);
                    KeyReceivedByClient = (int)buffer[0];
                    running = false;
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        running= true;
        System.out.println(" Connection established ");

        while (running){
            try{
                //Receive a DatagramPacket (note that the string cant be more than 80 chars)
                byte[] buffer = new byte[bufferSize];
                DatagramPacket packet = new DatagramPacket(buffer, bufferSize);
                receiving_socket.receive(packet);
                ByteBuffer VoIPpacket = ByteBuffer.wrap(buffer);//packet.getData());
                byte seqnum = VoIPpacket.get();
                byte[] audioBuffer = new byte[audioBufferSize];
                VoIPpacket.get(audioBuffer,0,audioBufferSize);
                //Get a audio from the byte buffer
                //System.out.println(seqnum+" "+Arrays.toString(audioBuffer));


            } catch (IOException e){
                System.out.println("ERROR: AudioReceiver: Some random IO error occured!");
                e.printStackTrace();
            }
        }
        //Close the socket
        receiving_socket.close();
        //Close audio output
        //player.close();
    }
    public byte[] decryption(ByteBuffer cipherText){ //security layer
        //System.out.println(Arrays.toString(cipherText.array()));
        ByteBuffer unwrapDecrypt = ByteBuffer.allocate(audioBufferSize);
        for(int j = 0; j < audioBufferSize/4; j++) {
            int fourByte = cipherText.getInt();
            if (j%2 == 1) {
                fourByte = fourByte ^ key; // XOR decrypt
            }else{
                fourByte = fourByte ^ key2;
            }
            unwrapDecrypt.putInt((int)fourByte);
        }
        byte[] decryptedBlock = unwrapDecrypt.array();
        //System.out.println(Arrays.toString(decryptedBlock));
        return decryptedBlock;
    }
    public void RSAdecryption(byte cipherText, byte cipherText2){ //RSA decryption
        System.out.println("before "+cipherText);
        double temp = (Math.pow(cipherText,privateKey[1]))%(double)privateKey[0];
        key = (int)temp;
        System.out.println("key "+key);
        System.out.println("before "+cipherText2);
        temp = (Math.pow(cipherText2,privateKey[1]))%(double)privateKey[0];
        key2 = (int)temp;
        System.out.println("key "+key2);
    }

    public static int[] getClientPublicKey(){return clientPublicKey;}
}
