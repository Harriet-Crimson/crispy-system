/*
created on 25th February 2026
description: AudioStandards java file holds the VoIP packet standards
version: 1.6
date: 08/03/2026
author(s): Harriet Smith
*/
import java.net.DatagramSocket;

public class AudioStandards {
    //Transport Layer -> Packet standards
    static int audioBufferSize = 512;
    static int seqSize = 1;
    static int packetsRange = 35;//max 127
    static int bufferSize = seqSize + audioBufferSize;

    //Network Layer -> Port
    static int PORT = 5555;

    //Security Layer -> Keys
    static int keyNum = 35;
    static int[] publicKey = {keyNum,5};
    static int[] privateKey = {keyNum,29};
    static int[] clientPublicKey;
    static int keyReceived = 0;
    static int KeyReceivedByClient = 0;
}
