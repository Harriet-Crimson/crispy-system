/*
created on 3rd February 2026
description: AudioSender java file encrypts and sends VoIP packets to client
version: 1.6
date: 08/03/2026
author(s): Harriet Smith
*/
import java.io.*;
import java.net.*;
import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Vector;

import CMPC3M06.AudioRecorder;
import uk.ac.uea.cmp.voip.DatagramSocket2;
import uk.ac.uea.cmp.voip.DatagramSocket3;

import javax.sound.sampled.LineUnavailableException;


public class AudioSender extends AudioStandards implements Runnable{
    private double recordTime = 0.032*(double)packetsRange;
    private String client = "localhost";
    static DatagramSocket sending_socket;
    private InetAddress clientIP = null;
    //private AudioRecorder recorder = new AudioRecorder();
    private int key = 33;
    private int key2 = 19;
    //static int[] clientPublicKey;

    public AudioSender() throws LineUnavailableException {
    }

    public void start(){
        Thread thread = new Thread(this);
        thread.start();
    }

    public void run(){
        //IP ADDRESS to send to
        try {
            clientIP = InetAddress.getByName(client);
            System.out.println("Client IP: " + clientIP.getHostAddress());
        } catch (UnknownHostException e) {
            System.out.println("ERROR: AudioSender: Could not find client IP");
            e.printStackTrace();
            System.exit(0);
        }

        try{
            sending_socket = new DatagramSocket();
            //sending_socket = new DatagramSocket2();
            //sending_socket = new DatagramSocket3();

        } catch (SocketException e){
            System.out.println("ERROR: AudioSender: Could not open UDP socket to send from.");
            e.printStackTrace();
            System.exit(0);
        }
        //Get a handle to the Standard Input (console) so we can read user input

        boolean connecting = true;
        byte sendkey = 0;
        byte sendkey2 = 0;
        while (connecting) {
            try { // send public key to client
                clientPublicKey = AudioReceiver.clientPublicKey;
                if (clientPublicKey != null) {
                    keyReceived = -1;
                    sendkey =RSAencryption((byte)key);
                    sendkey2 = RSAencryption((byte)key2);
                    if (KeyReceivedByClient == -1) {
                        connecting = false;
                    }
                }
                byte[] bufferPacket = {(byte) keyReceived,(byte) publicKey[0], (byte) publicKey[1],sendkey,sendkey2};
                DatagramPacket keypacket = new DatagramPacket(bufferPacket, bufferPacket.length, clientIP, PORT);
                sending_socket.send(keypacket);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

        boolean running = true;
        System.out.println("success");
        while (running){
            try{
                recordAudio();
            } catch (IOException e){
                System.out.println("ERROR: AudioSender: Some random IO error occured!");
                e.printStackTrace();
            } catch (LineUnavailableException e) {
                throw new RuntimeException(e);
            }
        }
        //Close the socket
        sending_socket.close();
        //Close audio input
        //recorder.close();
    }
    public byte RSAencryption(byte plaintext){
        boolean findkey = true;
        while (findkey) {
            if (clientPublicKey != null){
                findkey = false;
            }
        }
        //System.out.println("before "+plaintext);
        double temp = (Math.pow(plaintext,clientPublicKey[1]))%(double)clientPublicKey[0];
        //System.out.println("after "+temp);
        return (byte) temp;
    }

    public byte[] encryption(ByteBuffer plainText){ //security layer
        ByteBuffer unwrapEncrypt = ByteBuffer.allocate(audioBufferSize);
        for( int j = 0; j < audioBufferSize/4; j++) {
            int fourByte = plainText.getInt();
            if (j%2 == 1) {
                fourByte = fourByte ^ key; // XOR operation with key
            }else {
                fourByte= fourByte ^ key2;
            }
            unwrapEncrypt.putInt((int)fourByte);
        }
        byte[] encryptedBlock = unwrapEncrypt.array();
        return encryptedBlock;
    }

    public void recordAudio()throws LineUnavailableException, IOException{
        for (int i = 0; i < Math.ceil(recordTime / 0.032); i++) {
            //byte[] block = recorder.getBlock();
            //System.out.println(Arrays.toString(block));
            DatagramPacket packet = VoIPPacket(i, new byte[]{1, 2, 3, 4});
            //Send it
            sending_socket.send(packet);
        }
    }
    public DatagramPacket VoIPPacket(int seqnum, byte[] block){
        ByteBuffer VoIPpacket = ByteBuffer.allocate(bufferSize);
        VoIPpacket.put((byte)seqnum); //seq num
        VoIPpacket.put(block);
        //Make a DatagramPacket from it, with client address and port number
        byte[] bufferPacket = VoIPpacket.array();
        return new DatagramPacket(bufferPacket, bufferSize, clientIP, PORT);
    }

}
