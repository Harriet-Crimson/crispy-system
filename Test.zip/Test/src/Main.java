/*
created on 3rd February 2026
description: main java file for VoIP runs the threads.
version: 1.6
date: 08/03/2026
author(s): Harriet Smith
*/

import javax.sound.sampled.LineUnavailableException;

public class Main{
    public static void main(String[] args) throws LineUnavailableException {
        AudioReceiver audioReceiver = new AudioReceiver();
        AudioSender sender = new AudioSender();

        //start threads so they run simultaneously
        audioReceiver.start();
        sender.start();
    }
}